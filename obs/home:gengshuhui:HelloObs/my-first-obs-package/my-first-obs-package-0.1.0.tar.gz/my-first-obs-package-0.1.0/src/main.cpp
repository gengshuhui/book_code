#include <iostream>
 
int main()
{
    std::cout<<"Hello OBS!\n";
 
    return 0;
}
