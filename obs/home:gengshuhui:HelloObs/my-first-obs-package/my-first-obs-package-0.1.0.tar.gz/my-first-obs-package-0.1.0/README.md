# Example Upstream Project for OBS

This is an example project for the OBS Beginner's Guide.
